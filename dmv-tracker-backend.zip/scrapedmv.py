import json

# Example scraped data (replace with real scraping logic)
data = [
    {"location": "Charlotte East", "date": "2025-05-22", "available": True},
    {"location": "Raleigh Central", "date": "2025-05-23", "available": False},
]

with open("appointments.json", "w") as f:
    json.dump(data, f)
