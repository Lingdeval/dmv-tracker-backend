from flask import Flask, jsonify
import subprocess
import json
import os

app = Flask(__name__)

@app.route('/api/appointments', methods=['GET'])
def get_appointments():
    subprocess.run(["python3", "scrapedmv.py"], cwd=os.path.dirname(__file__))
    with open("appointments.json", "r") as f:
        data = json.load(f)
    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)
